from .similasyon import hesapla_yasam_tablosu

__all__ = ["hesapla_yasam_tablosu"]